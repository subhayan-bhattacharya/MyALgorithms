# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
HtmlFormsRuby::Application.config.secret_token = '870599295c9faf339ee82afb32de14cb09d3e0ea94a9d0ded78569c0ee7ae952892f74728c55278b9e1d37b2dbb2d557edd0faa1c512a8bcc4a9f2ae677490de'
