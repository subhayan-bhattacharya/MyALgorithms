class ProfileModel
      attr_accessor :firstName, :lastName, :email, :bio, :gender, :occupation, :marketing, :partners, :newsletter, :imagePath

end