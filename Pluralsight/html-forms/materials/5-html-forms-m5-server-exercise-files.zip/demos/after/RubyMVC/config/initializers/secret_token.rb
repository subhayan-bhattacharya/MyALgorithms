# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RubyMVC::Application.config.secret_token = 'bac291c30e98554e57bfafd1aa991b58c2d2295ed2b8f03c0bd723aa3bdd3b112deab2d63c05cc321d4222e83182b3f7ec5c42b874d554dc433c53738c25970d'
