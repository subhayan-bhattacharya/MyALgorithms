<?php
 class ProfileModel
 {
   public $firstName ;
   public $lastName;
   public $email;

   public $imagePath;
   public $occupation;
   public $gender;
   public $bio;

   public $newsletter;
   public $marketing;
   public $partnerOffers;
 }
?>

